

//
// Wong Limsoon
// 29/9/2020
//



import synchrony.gmql.EncodeNP._
import synchrony.gmql.SampleFileOps._
import OpG.{ count, average, smallest, stats }
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._


// Some functions for showing contents of samples.


def showSamples(samples: SampleFile) =
  for(s <- samples.eiterator) { 
    println(s); println("**")
  }


def showTotalSizeOnDisk(samples: SampleFile) = samples.totalsizeOnDisk


def showTrack(sample:Sample) = for(e <- sample.track) println(e) 


def showSize(sample:Sample) =
{
  val size = sample.bedFile.filesize
  val count = sample.track.length
  println(s"track size = ${size}, track count = ${count}")
}


def showTiming[A](codes: => A): A = {
  val t0 = System.nanoTime;
  val res = codes
  val dt = (System.nanoTime - t0) / 1e9d;
  println(s"Time take: ${dt}")
  res
}


// ctcfPath is the directory of ctcf samples.
// ctcfList is the list of ctcf samples.

val dir = "../../synchrony-1/test/test-massive/"
val ctcfPath = dir + "cistrome_hepg2_narrowpeak_ctcf/files"
val ctcfList = dir + "ctcf-list.txt"


// ctcfFiles is an EFile of samples.
// i.e. ctcfFiles.eiterator is an iterator on the ctcf samples.

val ctcfFiles = altOnDiskEncodeNPSampleFile(ctcfPath)(ctcfList)


// Some checks to see whether ctfc samples got loaded ok.

showSamples(ctcfFiles)  // display the ctcf samples

showTotalSizeOnDisk(ctcfFiles) // display size of ctcf files in total.

showTrack(ctcfFiles(3)) // display the track of sample #3; ie. 4th sample

showSize(ctcfFiles(0))  // display the track size of sample #0.


// Laziness...
//
// Our GMQL emulation is lazy. Query results are returned
// as an iterator, and the items in the results are produced
// only on-demand.

val ctcfdb = ctcfFiles.tracksSortedIfNeeded

ctcfdb(0) // the first item of the result.

ctcfdb(0) // the *next* item.


// Materializing ...
//
// You can however materialize a query either
// in memory, on disk, or let the system decides.
// Then all the results get computed in one go.

val ctcfdb = ctcfFiles.tracksSortedIfNeeded.materialized



ctcfdb(0) // first item of the result.

ctcfdb(0) // still the first item of the result.

ctcfdb(3) // the 4th item of the result.


val mm = {
  ctcfdb(0).bedFileUpdated(ctcfdb(2).bedFile mergedWith ctcfdb(3).bedFile)
}
   //
   // merge the tracks of sample #2 and sample #3,
   // replace the track of sample #1 with this merged track.

ctcfdb(2).track.length
ctcfdb(3).track.length
mm.track.length
   //
   // the first two numbers should sum to the third number.



// Simple GMQL queries ...
//
// These queries dont use Synchrony iterators.


val q1a = ctcfdb.selectS(
 onSample = _.track.length > 50000
).materialized

val q1 = ctcfdb.selectS(count[Bed](_) > 50000).materialized




showSamples(q1)

for(s <- ctcfdb) println(s.track.length)

for(s <- q1) println(s.track.length)




val q2 = ctcfdb.onRegion( _.selectR( _.chrom == "chr1")).materialized


showSamples(q2)

showTrack(q2(1))  // Display the track of sample #1 in q2.

for(s <- q2) println(s.track.length)


val q3a = {
  ctcfdb
  .extendS(
     "bed-count" -> count[Bed], 
     "myid" -> "sid")
  .materialized
}


val q3 = ctcfdb.projectS( "bed-count" -> count[Bed]).materialized


showSamples(q3)

for(s <- q3) println(s[Double]("bed-count"))


val q4 = {
   ctcfdb
   .projectS(
     "bed-count" -> count[Bed], 
     "sid" -> "sid")
   .materialized
}


for(s <- q4) println(s[String]("sid"), s[Double]("bed-count"))

showSamples(q4)



// Tests for more complicated queries.
//
// These queries use Synchrony iterators.


val mapres2 = showTiming {
  ctcfdb
  .mapS(ctcfdb)(onRegion =  mapR("avg_score" -> average(_.score),
                                 "stats" -> stats(_.score)))
  .materialized
}



val mapres = showTiming { 
  ctcfdb
   .mapS(ctcfdb)(
      onRegion = mapR("avg_score" -> average(_.score)),
      joinby = (u, v) => u("sid") == v("sid"))
   .materialized
}


showSamples(mapres)

showTrack(mapres(0))

showSize(mapres(0))



val grpbysid = {
  mapres2
  .groupbyS(
     grp = "sid",
     aggr = "count" -> count[Sample])
  .materialized
}


showSamples(grpbysid)

showTrack(grpbysid(1))




val grpbylocus = {
  mapres
  .onRegion(
     partitionbyR(
     aggr = "min-score" -> smallest(_.score), "reg-count" -> count))
  .materialized
}


showSamples(grpbylocus)

showSize(grpbylocus.samples(1))

grpbylocus(1).bedFile(5)  // Display region #5 on sample #1's track


{
  // test in grpbylocus whether sample #1's track is sorted.

  import synchrony.programming.Sri.withSlidingN

  val leq = Bed.ordering.lteq _

  grpbylocus(1).bedFile flatAggregateBy { withSlidingN(1) {
    OpG.forall { case (x, y) => leq(x(0), y) } } }
}
 



val refdb = SampleFile.inMemorySampleFile {
   ctcfdb.eiterator.take(1).toVector
}

val extdb = SampleFile.inMemorySampleFile {
   ctcfdb.eiterator.drop(1).toVector
}

val diffdb = showTiming {
  refdb.differenceS(extdb)(exact = false).materialized
}


showSamples(diffdb)

showTrack(diffdb(0))

showSize(ctcfdb(0))

showSize(diffdb(0))




val joindb = showTiming {
  refdb
  .joinS(ctcfdb)(
     onRegion = joinR(geno = DGE(5000), DLE(100000))(limit = 100000))
  .materialized
}

joindb.eiterator.length

showSamples(joindb)

showSize(joindb(0))




val projres = showTiming {
  ctcfdb
  .projectS(onSample = "sid" -> metaS[String]("sid"),
                       "bed-count" -> aggrS(count))
  .materialized
}

val projres2 = showTiming {
  ctcfdb
  .projectS(onSample = "sid" -> "sid",
                       "bed-count" -> count[Bed])
  .materialized
}


showSamples(projres)


val selres = showTiming {
  ctcfdb
  .onRegion(_.selectR(_.chrom == "chr1"))
  .materialized
}


selres.slurped

selres(1).bedFile(10)




