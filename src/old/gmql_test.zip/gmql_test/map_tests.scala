package synchrony.gmql_test

import scala.collection.immutable.ListMap

import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

import scala.math


object MapTests {

	// Map-s testname to the code to be run.
	val code: Map[String,(SampleFile,SampleFile) => SampleFile] = Map(
		"01" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"02" -> {
					case (db1,db2) => db1.mapS(db2)(
						onRegion=mapR("avg_score" -> OpG.average(_[Int]("score")))
					)
				},
		"03" -> {
					case (db1,db2) => db1.mapS(db2)(
						onRegion=mapR("min_score" -> OpG.smallest(_[Int]("score")))
		                   ("regNum"),
		    			joinby   = "database"
					)
				},
		"04" -> {
					case (db1,db2) => db1.onRegion(
						_.selectR(r => r.strand == "+")
					).mapS(db2.onRegion(
						_.selectR(r => r.strand == "+")
					))()
				},
		"P1" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P2" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P3" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P4" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P5" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P6" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P7" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P8" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P9" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P10" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P11" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P12" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P13" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P14" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P15" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P16" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P17" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P18" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P19" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P20" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P21" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P22" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		"P23" -> {
					case (db1,db2) => db1.mapS(db2)()
				},
		)

	// Map of correct values based on GMQL. -1: unknown / NA
	val correct: Map[String,Int] = Map(
		"01" -> 101306,
		"02" -> 101306,
		"03" -> 1681640,
		"04" -> 26004,
		"P1" -> 976,
		"P2" -> 10059,
		"P3" -> 100204,
		"P4" -> 111370,
		"P5" -> 1023580,
		"P6" -> 10070620,
		"P7" -> 16872000,
		"P8" -> 101231400,
		"P9" -> -1,
		"P10" -> 101306,
		"P11" -> 101306,
		"P12" -> 1681640,
		"P13" -> 26004,
		"P14" -> 976,
		"P15" -> 10059,
		"P16" -> 100204,
		"P17" -> 111370,
		"P18" -> 1023580,
		"P19" -> 10070620,
		"P20" -> 16872000,
		"P21" -> 101231400,
		"P22" -> -1,
		"P23" -> -1,
		)


	def test(name: String,
		db1: SampleFile,
		db2: SampleFile,
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		// Input: test name, first db, second db, number of runs
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/
			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(name)(db1,db2),
				nexec
			)

			val c: Int = correct(name)

			(output, Reporter.getTotalCount(output) match {
				case h:Int if h == c => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): (Int,Int) = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		// Remove clutter from printouts
		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false


		// Note 1 /  the use of "tracksSorted", *not* tracksSortedIfNeeded. This 
		// ensures the BED files are saved into Synchrony's format.

		// Note 2/ the saved db is read back in using 
		// "SampleFile.onDiskSampleFile", *not* 
		// SampleFile.onDiskEncodeNPSampleFile. As the db was saved in Synchrony's 
		// format, the decoding overhead of onDiskEncodeNPSampleFile can be avoided.

		

		// Begin MAP tests
		
		// Comment any of these to prevent that particular test from being run
		val inputList: ListMap[String,(SampleFile,SampleFile)] = ListMap(
			// 01 through 04: verify logic and semantic correctness
			// "01" -> (dbs("RefSeq_genes")(),dbs("H1")()),
			// "02" -> (dbs("RefSeq_genes")(),dbs("H1")()),
			// "03" -> (dbs("GM12878")(),dbs("H1_diff_databases")()),
			// "04" -> (dbs("RefSeq_genes")(),dbs("TSS")()),
			// P1 through P90: performance comparisons with GMQL
			// "P1" -> (dbs("SS")(),dbs("SS")()),
			// "P2" -> (dbs("SM")(),dbs("SM")()),
			// "P3" -> (dbs("SB")(),dbs("SB")()),
			// "P4" -> (dbs("MS")(),dbs("MS")()),
			// "P5" -> (dbs("MM")(),dbs("MM")()),
			// "P6" -> (dbs("MB")(),dbs("MB")()),
			// "P7" -> (dbs("BS")(),dbs("BS")()),
			// "P8" -> (dbs("BM")(),dbs("BM")()),
			// "P9" -> (dbs("BB")(),dbs("BB")()),
			// P10 through P23: scaling tests
			"P10" -> (dbs("s1l100")(),dbs("s1l100")()),
			"P11" -> (dbs("s5l1000")(),dbs("s5l1000")()),
			"P12" -> (dbs("s10l1000")(),dbs("s10l1000")()),
			"P13" -> (dbs("s20l1000")(),dbs("s20l1000")()),
			"P14" -> (dbs("s50l1000")(),dbs("s50l1000")()),
			"P15" -> (dbs("s75l1000")(),dbs("s75l1000")()),
			"P16" -> (dbs("s100l1000")(),dbs("s100l1000")()),
			"P17" -> (dbs("s1l1")(),dbs("s1l1")()),
			"P18" -> (dbs("s1l10")(),dbs("s1l10")()),
			"P19" -> (dbs("s1l100")(),dbs("s1l100")()),
			"P20" -> (dbs("s1l1000")(),dbs("s1l1000")()),
			"P21" -> (dbs("s1l10000")(),dbs("s1l10000")()),
			"P22" -> (dbs("s1l100000")(),dbs("s1l100000")()),
			"P23" -> (dbs("s1l1000000")(),dbs("s1l1000000")()),
		)

		// This tests should oly be run 5 times
		val heavyTests: List[String] = ("P6"::"P7"::"P8"::"P9" :: Nil)

		// Do all tests and save results in Map, avoiding loops and preserving DRYness
		val testResults: Map[String,(SampleFile,Int,Double,Double,Double,Double)] = 
			(
				for ( (id,(db1,db2)) <- inputList) yield {
					println(f"Running test ${id} [005.${id}]..."); 
					(id,test(id,db1,db2, if (heavyTests contains id) Constants.nexec_short else Constants.nexec_long))
				}
		).toMap

		// Print correctness and times
		testResults.foreach({case (k,v) => {println(Reporter.announce_result(f"Test ${k}",v._2));
											println(f"Timings for test ${k}");
											timeHeader.zip(List(v._3,v._4,v._5,v._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})};
											println("***********")})

		println("MAP tests completed")
		// Check how many are correct
		val passed_num = testResults.foldLeft(0)({case (acc,(k,v)) => acc + v._2})

		(passed_num, testResults.keySet.size)
	}
}