package synchrony.gmql_test

import synchrony.gmql.EncodeNP._

// import scala.io.Source._
// import scala.math
// import java.io.File
// import java.io.PrintWriter


object GMQLTests extends App {

	// Remove debug flags

	synchrony.iterators.Serializers.DEBUG = false // remove printouts
	synchrony.iterators.FileCollections.DEBUG = false // remove printouts
	// GMQL.Projections.DEBUG = false // remove printouts
	// GMQL.DEBUG = false // remove printouts

	// Clean tmp files
	// IMPORTANT: this assumes that java.io.tmpdir has been set to the same 
	// directory as Constants.tmp_folder (see demo_utilities)
	println("Cleaning files...")
	Cleaner.cleanAll()

	// All databases needed
	val dbnames = List("H1","H1_diff_databases","HG19_BED_ANNOTATION",
		"ncbiRefSeqCurated","GM12878","TSS","A549","HeLa-S3","K562",
		"covertest","SS","SM","SB","MS","MM","MB","BS","BM","BB","s1l100",
		"s5l1000","s10l1000","s20l1000","s50l1000","s75l1000","s100l1000",
		"s1l1","s1l10","s1l100","s1l1000","s1l10000","s1l100000","s1l1000000")
	println(dbnames)
	// Load dbs in form of Map
	val dbs = Loader.loadDBs(dbnames,false)


	println(Reporter.getTotalCount(dbs("ncbiRefSeqCurated")()))

	// uncomment the operator(s) of interest
	println("Begin operators tests...")
	// println()
	// println("SELECT")
	// println()
	// val (selectPass, selectTotal) = SelectTests.runAll(dbs)
	// println(f"Number of tests passed: ${selectPass} (${selectPass*100/(selectTotal)}%4.2f %%)")
	println("******")
	// println()
	// println("PROJECT")
	// println()
	// val (projectPass, projectTotal) = ProjectTests.runAll(dbs)
	// println(f"Number of tests passed: ${projectPass} (${projectPass*100/(projectTotal)}%4.2f %%)")
	// println("******")
	// println()
	// println("EXTEND")
	// println()
	// val (extendPass, extendTotal) = ExtendTests.runAll(dbs)
	// println(f"Number of tests passed: ${extendPass} (${extendPass*100/(extendTotal)}%4.2f %%)")
	// println("******")
	// println()
	// println("GROUPBY")
	// println()
	// val (groupbyPass, groupbyTotal) = GroupByTests.runAll(dbs)
	// println(f"Number of tests passed: ${groupbyPass} (${groupbyPass*100/(groupbyTotal)}%4.2f %%)")
	// println("******")
	println()
	println("MAP")
	println()
	val (mapPass, mapTotal) = MapTests.runAll(dbs)
	println(f"Number of tests passed: ${mapPass} (${mapPass*100/(mapTotal)}%4.2f %%)")
	println("******")
	// println()
	// println("DIFFERENCE")
	// println()
	// val (differencePass, differenceTotal) = DifferenceTests.runAll(dbs)
	// println(f"Number of tests passed: ${differencePass} (${differencePass*100/(differenceTotal)}%4.2f %%)")
	// // println("******")
	// println()
	// println("JOIN")
	// println()
	// val (joinPass, joinTotal) =JoinTests.runAll(dbs)
	// println(f"Number of tests passed: ${joinPass} (${joinPass*100/(joinTotal)}%4.2f %%)")
	// println("******")
	// println()
	// println("COVER")
	// println()
	// val (coverPass, coverTotal) = CoverTests.runAll(dbs)
	// println(f"Number of tests passed: ${coverPass} (${coverPass*100/(coverTotal)}%4.2f %%)")
	// println("******")
	// println()
	// println()
	// println("USE_CASE")
	// println()
	// UseCase.runAll(dbs)
	// println(f"Number of tests passed: ${coverPass} (${coverPass*100/(coverTotal)}%4.2f %%)")
	println("******")
	println()
	println("All done. Shutting down. Have a nice day!")

}