package synchrony.gmql_test

import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFCover._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

import scala.math


object CoverTests {

	val code: Map[String,(SampleFile,Option[SampleFile]) => SampleFile] = Map(
		"T1" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=true)
					)
				},
		"T2" -> {case (db,_) => db.coverS(
					onRegion = coverR(between(2,3))(stranded=true)
					)
				},
		"T3" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(1))(stranded=true)
					)
				},
		"T4" -> {case (db,_) => db.coverS(
					onRegion = flatR(between(2,3))(stranded=true)
					)
				},
		"T5" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(1))(stranded=true)
					)
				},
		"T6" -> {case (db,_) => db.coverS(
					onRegion = summitR(between(2,3))(stranded=true)
					)
				},
		"T7" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(1))(stranded=true)
					)
				},
		"T8" -> {case (db,_) => db.coverS(
					onRegion = histoR(between(2,3))(stranded=true)
					)
				},
		"01" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"02" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(db.eiterator.toVector.length))(stranded=false)
					)
				},
		"03" -> {case (db,_) => db.coverS(
					onRegion = coverR(between(2,3))(stranded=true)
					)
				},
		"04" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false),
					groupby = "database"
					)
				},
		"05" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false)
					)
				},
		"06" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false),
					groupby = "database"
				)
				},
		"07" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(1))(stranded=false)
					)
				},
		"08" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(db.eiterator.toVector.length))(stranded=false)
					)
				},
		"09" -> {case (db,_) => db.coverS(
					onRegion = flatR(between(2,3))(stranded=true)
					)
				},
		"10" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(1))(stranded=false),
					groupby = "database"
					)
				},
		"11" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false)
					)
				},
		"12" -> {case (db,_) => db.coverS(
					onRegion = flatR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false),
					groupby = "database"
				)
				},
		"13" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(1))(stranded=false)
					)
				},
		"14" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(db.eiterator.toVector.length))(stranded=false)
					)
				},
		"15" -> {case (db,_) => db.coverS(
					onRegion = summitR(between(2,3))(stranded=true)
					)
				},
		"16" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(1))(stranded=false),
					groupby = "database"
					)
				},
		"17" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false)
					)
				},
		"18" -> {case (db,_) => db.coverS(
					onRegion = summitR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false),
					groupby = "database"
				)
				},
		"19" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(1))(stranded=false)
					)
				},
		"20" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(db.eiterator.toVector.length))(stranded=false)
					)
				},
		"21" -> {case (db,_) => db.coverS(
					onRegion = histoR(between(2,3))(stranded=true)
					)
				},
		"22" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(1))(stranded=false),
					groupby = "database"
					)
				},
		"23" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false)
					)
				},
		"24" -> {case (db,_) => db.coverS(
					onRegion = histoR(atleast(1),
							"minPVal" -> OpG.smallest(_[Double]("pval")))(stranded=false),
					groupby = "database"
				)
				},
		"P1" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P2" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P3" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P4" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P5" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P6" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P7" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P8" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P9" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P10" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P11" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P12" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P13" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P14" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P15" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P16" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P17" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P18" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P19" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P20" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P21" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P22" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		"P23" -> {case (db,_) => db.coverS(
					onRegion = coverR(atleast(1))(stranded=false)
					)
				},
		)

	val correct: Map[String,Int] = Map(
		// "T1" -> -1,
		// "T2" -> -1,
		// "T3" -> -1,
		// "T4" -> -1,
		// "T5" -> -1,
		// "T6" -> -1,
		// "T7" -> -1,
		// "T8" -> -1,
		// "01" -> 7143,
		// "02" -> 3646,
		// "03" -> 5599,
		// "04" -> 23593,
		// "05" -> 7143,
		// "06" -> 23593,
		// "07" -> 7143,
		"P1" -> -1,
		"P2" -> -1,
		"P3" -> -1,
		"P4" -> -1,
		"P5" -> -1,
		"P6" -> -1,
		"P7" -> -1,
		"P8" -> -1,
		"P9" -> -1,
		"P10" -> -1,
		"P11" -> -1,
		"P12" -> -1,
		"P13" -> -1,
		"P14" -> -1,
		"P15" -> -1,
		"P16" -> -1,
		"P17" -> -1,
		"P18" -> -1,
		"P19" -> -1,
		"P20" -> -1,
		"P21" -> -1,
		"P22" -> -1,
		"P23" -> -1,
		)


	def test(name: String,
		db1: SampleFile,
		odb: Option[SampleFile],
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/
			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(name)(db1,odb),
				nexec
			)


			// output.savedAs((Constants.wd / "output" / name).toString)
			// output.savedAs("ciao")
			(output, Reporter.getTotalCount(output)/2.0 match {
				case h:Double if h == correct(name) => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): (Int,Int) = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false


		// Note 1 /  the use of "tracksSorted", *not* tracksSortedIfNeeded. This 
		// ensures the BED files are saved into Synchrony's format.

		// Note 2/ the saved db is read back in using 
		// "SampleFile.onDiskSampleFile", *not* 
		// SampleFile.onDiskEncodeNPSampleFile. As the db was saved in Synchrony's 
		// format, the decoding overhead of onDiskEncodeNPSampleFile can be avoided.

		
		// Begin COVER tests

		val inputList: Map[String,(SampleFile,Option[SampleFile])] = Map(
			// "T1" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T2" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T3" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T4" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T5" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T6" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T7" -> (dbs("covertest")(),None),  // DEBUGGING
			// "T8" -> (dbs("covertest")(),None),  // DEBUGGING
			// "01" -> (dbs("H1")(),None),
			// "02" -> (dbs("H1")(),None),
			// "03" -> (dbs("RefSeq_genes")(),None),
			// "04" -> (dbs("H1_diff_databases")(),None),
			// "05" -> (dbs("H1")(),None),
			// "06" -> (dbs("H1_diff_databases")(),None),
			// "07" -> (dbs("H1")(),None),
			// "08" -> (dbs("H1")(),None),
			// "09" -> (dbs("RefSeq_genes")(),None),
			// "10" -> (dbs("H1_diff_databases")(),None),
			// "11" -> (dbs("H1")(),None),
			// "12" -> (dbs("H1_diff_databases")(),None),
			// "13" -> (dbs("H1")(),None),
			// "14" -> (dbs("H1")(),None),
			// "15" -> (dbs("RefSeq_genes")(),None),
			// "16" -> (dbs("H1_diff_databases")(),None),
			// "17" -> (dbs("H1")(),None),
			// "18" -> (dbs("H1_diff_databases")(),None),
			// "19" -> (dbs("H1")(),None),
			// "20" -> (dbs("H1")(),None),
			// "21" -> (dbs("RefSeq_genes")(),None),
			// "22" -> (dbs("H1_diff_databases")(),None),
			// "23" -> (dbs("H1")(),None),
			// "24" -> (dbs("H1_diff_databases")(),None),
			"P1" -> (dbs("SS")(),None),  
			"P2" -> (dbs("SM")(),None),  
			"P3" -> (dbs("SB")(),None),  
			"P4" -> (dbs("MS")(),None),  
			"P5" -> (dbs("MM")(),None),  
			"P6" -> (dbs("MB")(),None),  
			"P7" -> (dbs("BS")(),None),
			"P8" -> (dbs("BM")(),None),
			"P9" -> (dbs("BB")(),None),
			"P10" -> (dbs("s1l100")(),None),
			"P11" -> (dbs("s5l1000")(),None),
			"P12" -> (dbs("s10l1000")(),None),
			"P13" -> (dbs("s20l1000")(),None),
			"P14" -> (dbs("s50l1000")(),None),
			"P15" -> (dbs("s75l1000")(),None),
			"P16" -> (dbs("s100l1000")(),None),
			"P17" -> (dbs("s1l1")(),None),
			"P18" -> (dbs("s1l10")(),None),
			"P19" -> (dbs("s1l100")(),None),
			"P20" -> (dbs("s1l1000")(),None),
			"P21" -> (dbs("s1l10000")(),None),
			"P22" -> (dbs("s1l100000")(),None),
			"P23" -> (dbs("s1l1000000")(),None),
		)

		val heavyTests: List[String] = ("P7"::"P6"::"P8"::"P9" :: Nil)

		val testResults: Map[String,(SampleFile,Int,Double,Double,Double,Double)] = (for (
					(id,(db,odb)) <- inputList
				) yield {println(f"Running test ${id} [008.${id}]..."); (id,test(id,db,odb,
					if (heavyTests contains id) Constants.nexec_short else Constants.nexec_long))}).toMap

		testResults.foreach({case (k,v) => {println(Reporter.announce_result(f"Test ${k}",v._2));
											println(f"Timings for test ${k}");
											timeHeader.zip(List(v._3,v._4,v._5,v._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})};
											println("***********")})

		println("COVER tests completed")
		val passed_num = testResults.foldLeft(0)({case (acc,(k,v)) => acc + v._2})

		(passed_num, testResults.keySet.size)
	}
}