package synchrony.gmql_test

import sys.process._

// import synchrony.gmql.SampleFileOpsImplicit.AlwaysMaterialize._
// import synchrony.gmql.SampleFileOpsTimings

import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.genomeannot.BedFileOps._
// import synchrony.genomeannot.BedFileOps.{OpG => BedFileOpG}
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._

import synchrony.iterators._
import synchrony.iterators.AggrCollections._

// import OpG.{ count, average, smallest, stats }

import synchrony.gmql.EncodeNP._

import java.io._



object UseCaseOnly extends App {


// Given a set of genes and two sets of TFBS of TF1 and TF2,
// all on the + strand.
// Identify all pairs of TFBS (t1 in TF1, t2 in TF2) that are 
// near each other (<100bp) and are in the promoter of a gene.
// Promoter is taken as -2000by to +1000bp) of the TSS of the gene.

  synchrony.iterators.Serializers.DEBUG = false
  synchrony.iterators.FileCollections.DEBUG = false
  synchrony.genomeannot.BedWrapper.DEBUG = false



  val runs = 10


  def getFile(f: String) = {
    val dir = "tests/input/"
    val pth = dir + f + "/files"
    val lst = dir + f + "/list.txt"
    importEncodeNPSampleFile(pth)(lst)(f)
  }

  // val genes = getFile("ncbiRefSeqCurated")

  val genes = getFile("ncbiRefSeqCurated10X")

  // val fos = getFile("FOS_MCF-7")

  // val gata3 = getFile("GATA3_MCF-7")

  val mcf7 = getFile("MCF-7_10TF")
  println(mcf7.eiterator.foldLeft(0)((n,s) => n + s.track.length))

  val hepG2 = getFile("HepG2_10TF")
  println(hepG2.eiterator.foldLeft(0)((n,s) => n + s.track.length))


  // CASE1: Using only synchrony iterators

// isBefore and canSee
//
def bf(y: Bed, x: Bed) = y.isBefore(x)
def cs(y: Bed, x: Bed) = y.overlap(1)(x)
def nr(y: Bed, x: Bed) = y.near(100)(x)
def ov(y: Bed, x: Bed) = y.overlap(1)(x)
// promoter
//
def prom(x: Bed) = BedFileOps.Bed(x.chrom, x.chromStart - 2000, x.chromStart + 1000)


// Query to identify near-by pairs using Synchrony iterators
//
def pairs_sync = for (
  gs <- genes.eiterator;
  ts1 <- mcf7.eiterator;
  ts2 <- hepG2.eiterator;
  tr1 = ts1.track;  
  tr2 = ts2.track;
  g <- gs.track.filter(_.strand == "+").map(prom _);
  b1 <- tr1.syncedWith(g)(bf, cs);
  b2 <- tr2.syncedWith(g)(bf, cs);
  if b1.near(100)(b2)
) yield (g, b1, b2)

def pairs_short = for (
  gs <- genes;
  ts1 <- mcf7;
  ts2 <- hepG2;
  tr1 = ts1.track;  
  tr2 = ts2.track;
  gr = gs.track.filter(_.strand == "+").map(prom _);
  b1 <- tr1;
  b2 <- tr2.syncedWith(b1)(bf, nr);
  if !gr.syncedWith(b1)(bf, ov).filter(_.overlap(1)(b2)).isEmpty
) yield (b1, b2)

  def mean(l:Seq[Double]): Double = l.reduceLeft(_ + _)/l.length
  
  def std(l:Seq[Double]): Double = math.sqrt(mean(l.map((x:Double) => x * x)) - mean(l) * mean(l))


def showTiming[A](codes: => A): (A,Double) = {
  val t0 = System.nanoTime;
  val res = codes
  val dt = (System.nanoTime - t0) / 1e9d;
  println(s"Time take: ${dt} seconds")
  (res,dt)
}

// println("Synchrony only")
// val output_sync = for (
//   i <- 1 to runs
// ) yield showTiming(AggrIterator(pairs_short).aggregateBy(AggrCollections.OpG.count))

// output_sync.foreach(println)
// println("Average:")
// println(mean(output_sync.map(_._2)))
// println("Stdev")
// println(std(output_sync.map(_._2)))

pairs_sync.slice(0,10).foreach(println)

// ==== Solution using GMQL emulation ====


// extract gene promoters
//
// def pls = genes.onRegion(selectR(_.strand == "+"))
// def prm = pls.onRegion(projectR(
//   "chromStart" -> (_.chromStart - 2000),
//   "chromEnd" -> (_.chromStart + 1000)))

// // extract TFBS of TF1 on gene promoters
// //
// def m1 = mcf7.mapS(prm)(mapR())
// def r1 = m1.onRegion(selectR(_[Int]("count") > 0))

// // extract TFBS of TF2 on gene promoters
// //
// def m2 = hepG2.mapS(prm)(mapR())
// def r2 = m2.onRegion(selectR(_[Int]("count") > 0))

// // identify near-by pairs
// //
// def pairs_gmql = r1.joinS(r2)(joinR(DLE(100)))

// println("SynchroGMQL")

// val output_gmql = for (
//   i <- 1 to runs
// ) yield showTiming(pairs_gmql.eiterator.foldLeft(0)((n,s) => n + AggrIterator(s.bedFile.eiterator).aggregateBy(AggrCollections.OpG.count).sum))

// output_gmql.foreach(println)
// println("Average:")
// println(mean(output_gmql.map(_._2)))
// println("Stdev")
// println(std(output_gmql.map(_._2)))

}