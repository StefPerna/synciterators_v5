package synchrony.gmql_test

// import synchrony.gmql.GMQL
// import GMQL._
// import Predicates._
// import GMQL.Projections._
// import GMQL.GenomeLocus._
// import GMQL.DB._
// import GMQL.implicits._
import synchrony.gmql.SampleFileOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

// import scala.language.postfixOps
// import scala.io.Source._
// import scala.collection.mutable.ListBuffer
import scala.math

// import java.io.File
// import java.io.PrintWriter


object GroupByTests {

	val code: Map[String,(SampleFile,Option[SampleFile]) => SampleFile] = Map(
		"01" -> {
					case (db,_) => db.extendS(
						onSample=("reg_num",_.track.length)
					).groupbyS(
						"database",
						("MaxSize",OpG.biggest(_.meta("reg_num").asInstanceOf[Int]))
					)
				},
		"02" -> {
					case (db,_) => db.groupbyS(
						grp = "database",
						aggr = "n_samp" -> OpG.count[Sample]
					)
				},
		"03" -> {
					case (db,_) => db.onRegion(
						partitionbyR(
							"regNum" -> OpG.count[Bed])
					)
				},
		"04" -> {
					case (db,_) => db.onRegion(
						partitionbyR("score",
							"avg_pvalue" -> OpG.average(_[Int]("score")),
							"max_qvalue" -> OpG.average(_[Int]("score")))
					)
				},
		"05" -> {
					case (db,_) => db.extendS(
							onSample=("reg_num",_.track.length)
						).groupbyS(
							"database",
							"max_reg" -> OpG.biggest(_.meta("reg_num").asInstanceOf[Int])
						).onRegion(
						partitionbyR(
							"min_signal" -> OpG.average(metaR[Double]("signalval"))
						)
					)
				},
		)

	val correct: Map[String,Int] = Map(
		"01" -> 30702,
		"02" -> 30702,
		"03" -> 9926,
		"04" -> 27659,
		"05" -> 27659,
		)


	def test(name: String,
		db1: SampleFile,
		odb: Option[SampleFile],
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/
			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(name)(db1,odb),
				nexec
			)

			val c: Int = correct(name)

			Reporter.report(output)

			(output, Reporter.getTotalCount(output) match {
				case h:Int if h == c => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): (Int,Int) = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false


		// Note 1 /  the use of "tracksSorted", *not* tracksSortedIfNeeded. This 
		// ensures the BED files are saved into Synchrony's format.

		// Note 2/ the saved db is read back in using 
		// "SampleFile.onDiskSampleFile", *not* 
		// SampleFile.onDiskEncodeNPSampleFile. As the db was saved in Synchrony's 
		// format, the decoding overhead of onDiskEncodeNPSampleFile can be avoided.

		

		// Begin GROUPBY tests

		val inputList: Map[String,(SampleFile,Option[SampleFile])] = Map(
			"01" -> (dbs("H1_diff_databases")(),None),
			"02" -> (dbs("H1_diff_databases")(),None),
			"03" -> (dbs("H1")(),None),
			"04" -> (dbs("H1_diff_databases")(),None),
			"05" -> (dbs("H1_diff_databases")(),None),
		)

		val testResults: Map[String,(SampleFile,Int,Double,Double,Double,Double)] = (for (
					(id,(db,odb)) <- inputList
				) yield {println(f"Running test ${id} [004.${id}]..."); (id,test(id,db,odb,Constants.nexec_long))}).toMap

		testResults.foreach({case (k,v) => {println(Reporter.announce_result(f"Test ${k}",v._2));
											println(f"Timings for test ${k}");
											timeHeader.zip(List(v._3,v._4,v._5,v._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})};
											println("***********")})

		println("GROUPBY tests completed")
		val passed_num = testResults.foldLeft(0)({case (acc,(k,v)) => acc + v._2})
		val ntests = testResults.keySet.size
		assert(ntests >= passed_num, "YOU FORGOT TO UPDATE SOMETHING!")

		(passed_num, ntests)
	}
}