package synchrony.gmql_test

import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFCover._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

import scala.math


object UseCase {

	val code: (SampleFile,SampleFile) => SampleFile = 
		{ case (genes,tfbs) => tfbs.mapS(
									genes.onRegion(_.selectR(
										r => r.strand == "+"
								).projectR(
												"chromStart" -> (_[Int]("chromStart") - 2000),
												"chromEnd" -> (_[Int]("chromStart") + 1000 + 1),
											)
										)
								)(
									onRegion=mapR("found" -> OpG.count)
								).onRegion(
									_.selectR( r => r.misc("found").asInstanceOf[Int] > 2)
								)
		}
		// "TFBS_use_case" -> {case (genes,tfbs) => 
		// 							tfbs.map(
		// 								region=OnRegion("found" as Count))(
		// 								genes.project(region=OnRegion("chromStart" as Start - 2000,
		// 									"chromEnd" as Start + 1 + 1000))).select(
		// 								region=OnRegion(MetaR[Double]("found")>0))},

	val correct: Int = 537940


	def test(code: (SampleFile,SampleFile) => SampleFile,
		db1: SampleFile,
		odb: SampleFile,
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/
			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(db1,odb),
				nexec
			)

			println(Reporter.getTotalCount(output))

			// output.savedAs((Constants.wd / "output" / name).toString)
			// output.savedAs("ciao")
			(output, Reporter.getTotalCount(output)/2.0 match {
				case h:Double if h == correct => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): Unit = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false


		// Note 1 /  the use of "tracksSorted", *not* tracksSortedIfNeeded. This 
		// ensures the BED files are saved into Synchrony's format.

		// Note 2/ the saved db is read back in using 
		// "SampleFile.onDiskSampleFile", *not* 
		// SampleFile.onDiskEncodeNPSampleFile. As the db was saved in Synchrony's 
		// format, the decoding overhead of onDiskEncodeNPSampleFile can be avoided.

		
		// Begin use_case

		val inputList: (SampleFile, SampleFile) = (dbs("ncbiRefSeqCurated")(),dbs("K562")())

		println("Running test case...")
		val testResults: (SampleFile,Int,Double,Double,Double,Double) = test(code,inputList._1,inputList._2,10)
		
		println(Reporter.announce_result(f"Use case",testResults._2))
		println(f"Timings:")
		timeHeader.zip(List(testResults._3,testResults._4,testResults._5,testResults._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})
		println("***********")

		println("Use case completed.")
	}
}