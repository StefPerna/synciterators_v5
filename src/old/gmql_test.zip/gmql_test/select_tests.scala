package synchrony.gmql_test

// import synchrony.gmql.GMQL
// import GMQL._
// import Predicates._
// import GMQL.Projections._
// import GMQL.GenomeLocus._
// import GMQL.DB._
// import GMQL.implicits._
import synchrony.gmql.SampleFileOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.BedFileOps._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

// import scala.language.postfixOps
// import scala.io.Source._
// import scala.collection.mutable.ListBuffer
import scala.math

// import java.io.File
// import java.io.PrintWriter


object SelectTests {

	val code: Map[String,(SampleFile,Option[SampleFile]) => SampleFile] = Map(
		"01" -> {case (db,_) => db.selectS()},
		"02" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"03" -> {case (db,_) => db.selectS(onSample=_.meta("TF")=="REST-human")},
		"04" -> {case (db,_) => db.onRegion({  
					_.selectR( r => 
						(r.chrom == "chr1" || r.chrom == "chr2") 
					&& r.strand != "+"
					&& r.chromStart >= 500000
					&& r.chromEnd <= 600000
				)
				})},
		"05" -> {case (db,_) => db.onRegion({  
					_.selectR( r => 
						r.misc("qval").asInstanceOf[Double] >= 4.1)
				})},
		"06" -> {case (rdb,odb) => rdb.selectS(
				onSample=(s:Sample) => s.meta("TF")!="FOSL1" && s.semijoin()("database")(odb.getOrElse(throw new Exception("Something is wrong"))))},
		"07" -> {case (db,_) => db.selectS(
					onSample = (s:Sample) => OpG.average((b:Bed) => b.misc("qval").asInstanceOf[Double])(s) > OpG.biggest((b:Bed) => b.misc("pval").asInstanceOf[Double])(s)
				)},
		"08" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "strange" || r.chrom == "funny")
				})},
		"P1" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P2" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P3" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P4" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P5" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P6" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P7" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P8" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P9" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P10" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P11" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P12" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P13" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P14" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P15" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P16" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P17" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P18" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P19" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P20" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P21" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P22" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		"P23" -> {case (db,_) => db.onRegion({  
					_.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
				})},
		)

	val correct: Map[String,Int] = Map(
		"01" -> 12969,
		"02" -> 2071,
		"03" -> 5995,
		"04" -> 12,
		"05" -> 11111,
		"06" -> 14038,
		"07" -> 12969,
		"08" -> 0,
		"P1" -> 160,
		"P2" -> 1794,
		"P3" -> 17938,
		"P4" -> 1811,
		"P5" -> 18202,
		"P6" -> 184208,
		"P7" -> 26985,
		"P8" -> 181941,
		"P9" -> 1786890,
		"P10" -> 160,
		"P11" -> 1794,
		"P12" -> 17938,
		"P13" -> 1811,
		"P14" -> 18202,
		"P15" -> 184208,
		"P16" -> 26985,
		"P17" -> 181941,
		"P18" -> 1786890,
		"P19" -> 18202,
		"P20" -> 184208,
		"P21" -> 26985,
		"P22" -> 181941,
		"P23" -> 1786890,
		)


	def test(name: String,
		db1: SampleFile,
		odb: Option[SampleFile],
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/

			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(name)(db1,odb),
				nexec
			)

			val c: Int = correct(name)

			println(Reporter.getTotalCount(output))

			(output, Reporter.getTotalCount(output) match {
				case h:Int if h == c => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): (Int,Int) = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false

		// Begin SELECT tests

		val inputList: Map[String,(SampleFile,Option[SampleFile])] = Map(
			"01" -> (dbs("H1")(),None),
			"02" -> (dbs("H1")(),None),
			"03" -> (dbs("H1")(),None),
			"04" -> (dbs("HG19_BED_ANNOTATION")(),None),
			"05" -> (dbs("H1")(),None),
			"06" -> (dbs("H1_diff_databases")(),Some(dbs("H1")())),
			"07" -> (dbs("H1_diff_databases")(),None),
			"08" -> (dbs("BB")(),None),
			// "P1" -> (dbs("SS")(),None),
			// "P2" -> (dbs("SM")(),None),
			// "P3" -> (dbs("SB")(),None),
			// "P4" -> (dbs("MS")(),None),
			// "P5" -> (dbs("MM")(),None),
			// "P6" -> (dbs("MB")(),None),
			// "P7" -> (dbs("BS")(),None),
			// "P8" -> (dbs("BM")(),None),
			// "P9" -> (dbs("BB")(),None),
			// "P10" -> (dbs("s1l1000")(),None),
			// "P11" -> (dbs("s5l1000")(),None),
			// "P12" -> (dbs("s10l1000")(),None),
			// "P13" -> (dbs("s20l1000")(),None),
			// "P14" -> (dbs("s50l1000")(),None),
			// "P15" -> (dbs("s75l1000")(),None),
			// "P16" -> (dbs("s100l1000")(),None),
			// "P17" -> (dbs("s1l1")(),None),
			// "P18" -> (dbs("s1l10")(),None),
			// "P19" -> (dbs("s1l100")(),None),
			// "P20" -> (dbs("s1l1000")(),None),
			// "P21" -> (dbs("s1l10000")(),None),
			// "P22" -> (dbs("s1l100000")(),None),
			// "P23" -> (dbs("s1l1000000")(),None),
		)

		val heavyTests: List[String] = ("P7"::"P6"::"P8"::"P9" :: Nil)

		val testResults: Map[String,(SampleFile,Int,Double,Double,Double,Double)] = (for (
					(id,(db,odb)) <- inputList
				) yield {println(f"Running test ${id} [001.${id}]..."); (id,test(id,db,odb,
					if (heavyTests contains id) Constants.nexec_short else Constants.nexec_long))}).toMap
		println("Saving...")
		testResults.foreach({case (k,v) => {//v._1.savedAs((Constants.wd / "tests" / "output" / k).toString);
											println(Reporter.announce_result(f"Test ${k}",v._2));
											println(f"Timings for test ${k}");
											timeHeader.zip(List(v._3,v._4,v._5,v._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})};
											println("***********")})

		println("SELECT tests completed")
		val passed_num = testResults.foldLeft(0)({case (acc,(k,v)) => acc + v._2})
		val ntests = testResults.keySet.size
		assert(ntests >= passed_num, "YOU FORGOT TO UPDATE SOMETHING!")

		(passed_num, ntests)
	}
}