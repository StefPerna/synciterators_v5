package synchrony.gmql_test

import sys.process._

// import synchrony.pargmql.SampleFileParOps._
// import synchrony.gmql.SampleFileOps._
// import synchrony.pargmql.{ SampleFileParOps => SFP }
import synchrony.gmql.{ SampleFileOps => SF }
import synchrony.gmql.SampleFileOpsTimings

import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._

// import synchrony.pargmql.SampleFileParOpsImplicit.AlwaysMaterialize._
// import synchrony.gmql.SampleFileOpsImplicit.AlwaysMaterialize._


import synchrony.gmql.EncodeNP._


object ParallelTests extends App {

  synchrony.iterators.Serializers.DEBUG = false
  synchrony.iterators.FileCollections.DEBUG = false
  synchrony.genomeannot.BedWrapper.DEBUG = false


  type Timings = SampleFileOpsTimings.Timings

  val runs = 10

  // val tmp_fldr = "/var/folders/k8/sf3vvc_921d8r9n7qgy_7kh00000gn/T"

  def getFile(f: String) = {
    val dir = "tests/input/"
    val pth = dir + f + "/files"
    val lst = dir + f + "/list.txt"
    importEncodeNPSampleFile(pth)(lst)(f)
  }


  val gm12878 = getFile("GM12878")
  val h1_diff_databases = getFile("H1_diff_databases")
  val h1 = getFile("H1")
  val refSeqGenes = getFile("RefSeqGenes")

  Reporter.report(refSeqGenes)
  Reporter.report(h1)



  // def qParMap(f1: SFP.SampleFile, f2: SFP.SampleFile) = SFP.SFOps.mapS(f1,f2)()
  def qMap(f1: SF.SampleFile, f2: SF.SampleFile) = SF.SFOps.mapS(f1,f2)(onRegion=mapR("avg_score" -> OpG.average(_[Int]("score"))))


  // val (timeP,resultP) = SampleFileOpsTimings.nRuns(runs)(qParMap(refSeqGenes,h1))

  // println()
  // println("MAP(*) parallel\n")

  // println(s"t = ${timeP.stats}\n")

  // Reporter.report(resultP.serialized)

  val (time,result) = SampleFileOpsTimings.nRuns(runs)(qMap(refSeqGenes,h1))

  println()
  println("MAP(*) sequential\n")

  println(s"t = ${time.stats}\n")

  Reporter.report(result.serialized)

}