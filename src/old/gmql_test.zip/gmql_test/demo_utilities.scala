package synchrony.gmql_test

import scala.collection.immutable.ListMap
import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOpsTimings
import scala.math._
import synchrony.gmql.EncodeNP._

object Constants {
	// Container for directories, temps, and other constants

	// directories
	val wd = os.pwd
	val tmp_folder = wd / "tmp" 

	// Execution and timing
	val nexec_sort = 1  // Can be changed if sorting is to be measured again
	val nexec_short = 5 // for huge tests that take > 1000s
	val nexec_long = 10 // normal value
	val byte2mb = 1024*1024
}


object Cleaner {
	// Convenience object that reset the tmp folder state

	def cleanTestOutput(tn: String) = os.remove.all(
		Constants.wd / "tests" / "output" / s"${tn}_output"
		)

	def cleanAll(): Unit = {
		cleanLocalTmp(Constants.wd)
		cleanTmpGarbage(Constants.tmp_folder)

	}

	// must filter with .startsWith to avoid remove sbt tmp files
	private def cleanLocalTmp(wd: os.Path) = os.list(
		wd / "tmp"
	).filter(f => f.toString.startsWith("synchrony-")).foreach(f => os.remove(f))

	private def cleanTmpGarbage(tmpd: os.Path) = os.walk(tmpd,skip = (p: os.Path) => !(p.last.startsWith("synchrony-"))).foreach(os.remove(_))
}


object Reporter {

	// Routing for printouts and reporting of results

	private val showLength: Int = 20
	def announce_result(tn:String, res:Int): String = res match {
			case 1 => f"${tn} passed!"
			case 0 => f"WARNING! ${tn} failed..."
			case _ => "Something went wrong here."
		}
	// Convenience object with auxiliary printing functions
	private def showSamples(samples: SampleFile) = samples.eiterator.foreach((s:Sample) => { println(s); println("**") } )

	private def showTrack(sample:Sample) = sample.track.foreach(println)

	private def showTrackHead(sample:Sample) = sample.track.slice(0,showLength).foreach(println)

	private def showSize(sample:Sample) = println(s"track size = ${sample.bedFile.filesize/1e3} KB, track count = ${sample.track.length}")

	private def showTotalSize(samples: SampleFile) = println(s"total track size = ${samples.totalsizeOnDisk/(1e6)} MB")

	private def showTotalCount(samples: SampleFile) = println(s"total track count = ${getTotalCount(samples)} lines")

	def getTotalCount(samples:SampleFile):Int = samples.eiterator.foldLeft(0)((n,s) => n + s.track.length)
		

	def report(samples:SampleFile)
	{
		showSamples(samples)
		showTotalSize(samples)
		showTotalCount(samples)
		samples.eiterator.zipWithIndex.foreach(
			{ case (s,count) => {println(s"Sample ${count}"); println(showSize(s)); showTrackHead(s)} }
		)
	}

}

object Loader {
	private def getDB(name:String, materialize:Boolean): () => SampleFile = {

		// Returns a tuple dbname -> thunk pointing to the saved SampleFile.
		// materialize: if true, load using importEncodeNPSampleFile and then materialize to tests/synchronyDBs

		if (materialize) {
			println(f"Loading ${name}");
			importEncodeNPSampleFile(
				(Constants.wd / "tests" / "input" / name / "files").toString)(
					(Constants.wd / "tests" / "input" / name / "list.txt").toString)(
						(Constants.wd / "tests" / "synchronyDBs" / name).toString)
		}

		def sortedDb = SampleFile.onDiskSampleFile((Constants.wd / "tests" / "synchronyDBs" / name).toString)

		() => sortedDb
	}

	def loadDBs(ls:List[String],materialize:Boolean): ListMap[String, () => SampleFile] = {
		val l = for (
				n <- ls
			) yield (n,getDB(n,materialize))
		ListMap(l: _*)
	}

}

object Timer {
	// Convenience class for timing tests
	private val runtime = Runtime.getRuntime

	private def mean(l:Seq[Double]): Double = l.reduceLeft(_ + _)/l.length
	
	private def std(l:Seq[Double]): Double = math.sqrt(mean(l.map((x:Double) => x * x)) - mean(l) * mean(l))

	def timeSortingOf(sample: SampleFile, ne: Int): (Double,Double) = {
		// Sorts the input sampleFile ne times and returns result, average, stdev
		val sortTimes = for (i <- 0 to (ne-1)) yield {
			((t:Long) => {
				sample.selectS().tracksSorted.materialized.savedAs("tmp"); 
				(System.nanoTime()-t)/1e9
			}) (System.nanoTime())
		}
		(mean(sortTimes),std(sortTimes))
	}


	def computeAndTime(code: => SampleFile,nex:Int): (SampleFile,Double,Double,Double,Double) = {
		// uses Nruns to time "nex" runs of the code. Returns average and std of times for
		// execution and writing.

		// val (exTimings,exRuns) = SampleFileOpsTimings.nRunsWithCleaning(nex)(code)

		// val (wrTimings,wrRuns) = nRuns(nex)(code.materialized)

		val (time, results) = SampleFileOpsTimings.nRuns(nex)(code)

		(results,time.stats.average,math.sqrt(time.stats.variance),
			time.stats.average,math.sqrt(time.stats.variance))
	}
}

// Not used in current version
// object SavUnwrapper {
// 	// reads and parses a sav file, then moves files from the temp variable folder


// 	def moveFiles(savpath:os.Path, tgtfldr:os.Path) {
// 		for (meta <- os.read.lines(savpath)
// 			if meta.split('\t')(0).startsWith("/var");
// 			p = os.Path(meta)) {
// 			os.move(p, tgtfldr / p.last)
// 		}
// 	}

// }