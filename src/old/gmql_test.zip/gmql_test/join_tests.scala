package synchrony.gmql_test

import scala.collection.immutable.ListMap

// import synchrony.gmql.GMQL
// import GMQL._
// import Predicates._
// import GMQL.Projections._
// import GMQL.GenomeLocus._
// import GMQL.DB._
// import GMQL.implicits._
import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.gmql.EncodeNP._
import synchrony.genomeannot.GenomeAnnot._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._
// import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.iterators.AggrCollections.{ AggrIterator, OpG }

// import scala.language.postfixOps
// import scala.io.Source._
// import scala.collection.mutable.ListBuffer
import scala.math

// import java.io.File
// import java.io.PrintWriter


object JoinTests {

	val code: Map[String,(SampleFile,SampleFile) => SampleFile] = ListMap(
		"01" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(DL(30000))(BFOut.left,ordering=BFOrder.distinct)
					)
				},
		"02" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(DL(100))(BFOut.both,limit=100)
					)
				},
		"03" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(DL(20))(BFOut.intersect),
						joinby="database"
					)
				},
		"04" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(DLE(0))(BFOut.intersect),
						joinby="database"
					)
				},
		"05" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(20))(BFOut.intersect),
						joinby="database"
					)
				},
		"06" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Touch)(BFOut.left),
						joinby="database"
					)
				},
		"07" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.left,
						screen=(l,r) => l.score == r.score)
					)
				},
		"08" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR(
								EndBefore
							)
							(
								BFCover.md(1)
							)(
								BFOut.right
							)
					)
				},
		"09" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR(
								StartAfter
							)
							(
								BFCover.md(1)
							)(
								BFOut.right
							)
					)
				},
		"10" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR(
								DGE(120000)
							)
							(
								BFCover.md(1)
							)(
								BFOut.right
							),
						joinby="database"
					)
				},
		"11" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR(
								DGE(120000)
							)
							(
								BFCover.md(1)
							)(
								ordering=BFOrder.distinct
							),
						joinby="database"
					)
				},
		"12" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR(
								DGE(120000)
							)
							(
								BFCover.md(1)
							)(
								BFOut.cat
							),
						joinby="database"
					)
				},
		"13" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(
								AndL(
									DLE(100000),DGE(5000)
								)
							)(
								BFOut.left
							)
					)
				},
		"14" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = iNearestR()
							(
								BFCover.md(1)
							)
							(
								BFOut.right
							)
					)
				},
		"P1" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P2" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P3" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P4" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P5" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P6" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P7" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P8" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P9" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P10" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P11" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P12" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P13" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P14" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P15" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P16" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P17" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P18" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P19" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P20" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P21" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P22" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		"P23" -> {
					case (db1,db2) => db1.joinS(db2)(
						onRegion = joinR(Overlap(1))(BFOut.intersect)
					)
				},
		)

	val correct: ListMap[String,Int] = ListMap(
		"01" -> 20320,
		"02" -> 1320,
		"03" -> 2605,
		"04" -> 2605,
		"05" -> 2557,
		"06" -> 2,
		"07" -> 29489,
		"08" -> 33122,
		"09" -> 33879,
		"10" -> 30440,
		"11" -> 11486,
		"12" -> 30440,
		"13" -> 165393,
		"14" -> 68002,
		"P1" -> 1022,
		"P2" -> 10879,
		"P3" -> 100204,
		"P4" -> 16711,
		"P5" -> 183722,
		"P6" -> 2794032,
		"P7" -> 1022384,
		"P8" -> 13048884,
		"P9" -> -1,
		"P10" -> -1,
		"P11" -> -1,
		"P12" -> -1,
		"P13" -> -1,
		"P14" -> -1,
		"P15" -> -1,
		"P16" -> -1,
		"P17" -> -1,
		"P18" -> -1,
		"P19" -> -1,
		"P20" -> -1,
		"P21" -> -1,
		"P22" -> -1,
		"P23" -> -1,
		)


	def test(name: String,
		db1: SampleFile,
		db2: SampleFile,
		nexec: Int): (SampleFile,Int,Double,Double,Double,Double) = {
		/* Returns:
			- OutputDB
			- whether the test was passed or not
			- average execution time over nexec runs
		 	- standard dev of execution time over nexec runs
			- average writing time over nexec runs
		 	- standard dev of writing time over nexec runs
		*/
			val (output, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime) = Timer.computeAndTime(
				code(name)(db1,db2),
				nexec
			)

			val c: Int = correct(name)

			// Reporter.report(output)

			(output, Reporter.getTotalCount(output) match {
				case h:Int if h == c => 1
				case _ => 0
			}, exMeanTime, exStdTime, 
				wrMeanTime, wrStdTime)
		}


	

	def runAll(dbs:Map[String, () =>SampleFile]): (Int,Int) = {

		val timeHeader=List("execution AVG time: ",
			"execution STD time: ",
			"writing AVG time: ",
			"writing STD time: ")

		synchrony.iterators.Serializers.DEBUG = false
		synchrony.iterators.FileCollections.DEBUG = false


		// Note 1 /  the use of "tracksSorted", *not* tracksSortedIfNeeded. This 
		// ensures the BED files are saved into Synchrony's format.

		// Note 2/ the saved db is read back in using 
		// "SampleFile.onDiskSampleFile", *not* 
		// SampleFile.onDiskEncodeNPSampleFile. As the db was saved in Synchrony's 
		// format, the decoding overhead of onDiskEncodeNPSampleFile can be avoided.

		

		// Begin JOIN tests

		val inputList: ListMap[String,(SampleFile,SampleFile)] = ListMap(
			// "01" -> (dbs("TSS")(),dbs("H1")()),
			// "02" -> (dbs("TSS")(),dbs("H1")()),
			// "03" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "04" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "05" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "06" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "07" -> (dbs("H1")(),dbs("H1_diff_databases")()),
			// "08" -> (dbs("TSS")(),dbs("H1")()),
			// "09" -> (dbs("TSS")(),dbs("H1")()),
			// "10" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "11" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "12" -> (dbs("H1_diff_databases")(),dbs("HeLa-S3")()),
			// "13" -> (dbs("TSS")(),dbs("H1")()),
			// "14" -> (dbs("TSS")(),dbs("H1")()),
			// "P1" -> (dbs("SS")(),dbs("SS")()),
			// "P2" -> (dbs("SM")(),dbs("SM")()),
			// "P3" -> (dbs("SB")(),dbs("SB")()),
			// "P4" -> (dbs("MS")(),dbs("MS")()),
			// "P5" -> (dbs("MM")(),dbs("MM")()),
			// "P6" -> (dbs("MB")(),dbs("MB")()),
			// "P7" -> (dbs("BS")(),dbs("BS")()),
			// "P8" -> (dbs("BM")(),dbs("BM")()),
			// "P9" -> (dbs("BB")(),dbs("BB")()),
			"P10" -> (dbs("s1l100")(),dbs("s1l100")()),
			"P11" -> (dbs("s5l1000")(),dbs("s5l1000")()),
			"P12" -> (dbs("s10l1000")(),dbs("s10l1000")()),
			"P13" -> (dbs("s20l1000")(),dbs("s20l1000")()),
			"P14" -> (dbs("s50l1000")(),dbs("s50l1000")()),
			"P15" -> (dbs("s75l1000")(),dbs("s75l1000")()),
			"P16" -> (dbs("s100l1000")(),dbs("s100l1000")()),
			"P17" -> (dbs("s1l1")(),dbs("s1l1")()),
			"P18" -> (dbs("s1l10")(),dbs("s1l10")()),
			"P19" -> (dbs("s1l100")(),dbs("s1l100")()),
			"P20" -> (dbs("s1l1000")(),dbs("s1l1000")()),
			"P21" -> (dbs("s1l10000")(),dbs("s1l10000")()),
			"P22" -> (dbs("s1l100000")(),dbs("s1l100000")()),
			"P23" -> (dbs("s1l1000000")(),dbs("s1l1000000")()),
		)

		val heavyTests: List[String] = ("08"::"P7"::"P6"::"P8"::"P9" :: Nil)


		val testResults: Map[String,(SampleFile,Int,Double,Double,Double,Double)] = (for (
					(id,(db1,db2)) <- inputList
				) yield {println(f"Running test ${id} [007.${id}]..."); (id,test(id,db1,db2,
					if (heavyTests contains id) Constants.nexec_short else Constants.nexec_long))}).toMap

		testResults.foreach({case (k,v) => {println(Reporter.announce_result(f"Test ${k}",v._2));
											//v._1.savedAs((Constants.wd / "tests" / "output" / k).toString);
											println(f"Timings for test ${k}");
											timeHeader.zip(List(v._3,v._4,v._5,v._6)).foreach({ case (u,v) => println(f"${u}${v}%.5f")})};
											println("***********")})

		println("JOIN tests completed")
		val passed_num = testResults.foldLeft(0)({case (acc,(k,v)) => acc + v._2})

		(passed_num, testResults.keySet.size)
	}
}