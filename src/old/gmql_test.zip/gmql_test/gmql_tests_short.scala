package synchrony.gmql_test

import sys.process._

import synchrony.gmql.SampleFileOpsImplicit.AlwaysMaterialize._
import synchrony.gmql.SampleFileOpsTimings


import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._

// import OpG.{ count, average, smallest, stats }

import synchrony.gmql.EncodeNP._



object GMQLTestsShort extends App {

  synchrony.iterators.Serializers.DEBUG = false
  synchrony.iterators.FileCollections.DEBUG = false
  synchrony.genomeannot.BedWrapper.DEBUG = false


  type Timings = SampleFileOpsTimings.Timings

  val runs = 10

  val tmp_fldr = "/var/folders/k8/sf3vvc_921d8r9n7qgy_7kh00000gn/T"


  def nRunsWithCleaning(
      n: Int, 
      samples: => SampleFile,
      tNoWrite: Timings = new Timings,
      tWrite: Timings = new Timings) = {

    var c: Int = 0
    while (c < n) {
      c = c + 1
      SampleFileOpsTimings.iaTimeIt(tNoWrite)(samples) 
      s"ls ${tmp_fldr}".!!.split("\n").map(_.trim).
      filter(r => r.startsWith("synchrony")).foreach(r => s"rm -rf ${tmp_fldr}/${r}".!)
    }

    c = 0
    while (c < n) {
      c = c + 1
      SampleFileOpsTimings.iaTimeIt(tWrite)(samples.materialized)
      s"ls ${tmp_fldr}".!!.split("\n").map(_.trim).
      filter(r => r.startsWith("synchrony")).foreach(r => s"rm -rf ${tmp_fldr}/${r}".!)
    }

  //
  //  (tNoWrite, tWrite, samples.materialized)
  //

    (tNoWrite, tWrite)
  }




  def getFile(f: String) = {
    val dir = "solo/"
    val pth = dir + f + "/files"
    val lst = dir + f + "/list.txt"
    importEncodeNPSampleFile(pth)(lst)(f)
  }

  val s1l1 = getFile("s1l1")
  val s1l10 = getFile("s1l10")
  val s1l100 = getFile("s1l100")
  val s1l1000 = getFile("s1l1000")
  val s1l10000 = getFile("s1l10000")
  val s1l100000 = getFile("s1l100000")
  val s1l1000000 = getFile("s1l1000000")
  val s5l1000 = getFile("s5l1000")
  val s10l1000 = getFile("s10l1000")
  val s20l1000 = getFile("s20l1000")
  val s50l1000 = getFile("s50l1000")
  val s75l1000 = getFile("s75l1000")
  val s100l1000 = getFile("s100l1000")



  val s1 = List(
             ("s1l1", s1l1), ("s1l10", s1l10), ("s1l100", s1l100),
             ("s1l1000", s1l1000), ("s1l10000", s1l10000), 
             ("s1l10000", s1l100000), ("s1l1000000", s1l1000000)
           )

  val s2 = List(
             ("s1l1000", s1l1000), ("s5l1000", s5l1000), ("s10l1000", s10l1000),
             ("s20l1000", s20l1000), ("s50l1000", s50l1000),
             ("s75l1000", s75l1000), ("s100l1000", s100l1000)
           )


  def qJoin(f: SampleFile) = f.joinS(f)(synchrony.genomeannot.BedFileOps.BFOps.joinR(Locus.Overlap(1)))



  val results2 = {
    for(
      (n, s) <- s2;
      (tnw, tww) = nRunsWithCleaning(runs, qJoin(s))
    ) yield (n, tnw, tww)
  }.toVector

  print("\n\n JOIN *** Scaling wrt # of samples - exec time ***\n\n")

  for ((n, tnw, tww) <- results2) print(s"n = ${n}, t = ${tnw.stats}\n\n")

  print("\n\n JOIN *** Scaling wrt # of samples - writing time ***\n\n")

  for ((n, tnw, tww) <- results2) print(s"n = ${n}, t = ${tww.stats}\n\n")



  val results1 = {
    for(
      (n, s) <- s1;
      (tnw, tww) = nRunsWithCleaning(runs, qJoin(s))
    ) yield (n, tnw, tww)
  }.toVector

  print("\n\n JOIN *** Scaling wrt region count - exec time ***\n\n")

  for ((n, tnw, tww) <- results1) print(s"n = ${n}, t = ${tnw.stats}\n\n")

  print("\n\n JOIN *** Scaling wrt region count - writing time ***\n\n")

  for ((n, tnw, tww) <- results1) print(s"n = ${n}, t = ${tww.stats}\n\n")

}