

//
// Wong Limsoon
// 15/10/2020
//



import synchrony.gmql.EncodeNP._
// import synchrony.gmql.SampleFileOpsImplicit.AlwaysSortIfNeeded._
import synchrony.gmql.SampleFileOpsImplicit.AlwaysMaterialize._
import OpG.{ count, average, smallest, stats }
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._


// Some functions for showing contents of samples.


def showSamples(samples: SampleFile) =
  for(s <- samples.eiterator) { 
    println(s); println("**")
  }


def showTotalSizeOnDisk(samples: SampleFile) = samples.totalsizeOnDisk


def showTrack(sample:Sample) = for(e <- sample.track) println(e) 


def showSize(sample:Sample) =
{
  val size = sample.bedFile.filesize
  val count = sample.track.length
  println(s"track size = ${size}, track count = ${count}")
}


def showTiming[A](codes: => A): A = {
  val t0 = System.nanoTime;
  val res = codes
  val dt = (System.nanoTime - t0) / 1e9d;
  println(s"Time take: ${dt}")
  res
}


// ctcfPath is the directory of ctcf samples.
// ctcfList is the list of ctcf samples.

val dir = "../../synchrony-1/test/test-massive/"
val ctcfPath = dir + "cistrome_hepg2_narrowpeak_ctcf/files"
val ctcfList = dir + "ctcf-list.txt"


// ctcfFiles is an EFile of samples.
// i.e. ctcfFiles.eiterator is an iterator on the ctcf samples.

val ctcfdb = importEncodeNPSampleFile(ctcfPath)(ctcfList)("ctcfdb")


ctcfdb(0) // first item of the result.

ctcfdb(0) // still the first item of the result.

ctcfdb(3) // the 4th item of the result.


val mm = {
  ctcfdb(0).bedFileUpdated(ctcfdb(2).bedFile mergedWith ctcfdb(3).bedFile)
}
   //
   // merge the tracks of sample #2 and sample #3,
   // replace the track of sample #1 with this merged track.

ctcfdb(2).track.length
ctcfdb(3).track.length
mm.track.length
   //
   // the first two numbers should sum to the third number.



// Simple GMQL queries ...
//
// These queries dont use Synchrony iterators.


val q1a = ctcfdb.selectS( onSample = _.track.length > 50000)

val q1 = ctcfdb.selectS(count[Bed](_) > 50000)




showSamples(q1)

for(s <- ctcfdb) println(s.track.length)

for(s <- q1) println(s.track.length)




val q2 = ctcfdb.onRegion( _.selectR( _.chrom == "chr3"))


showSamples(q2)

showTrack(q2(1))  // Display the track of sample #1 in q2.

for(s <- q2) println(s.track.length)


val q3a = {
  ctcfdb
  .extendS(
     "bed-count" -> count[Bed], 
     "myid" -> "sid")
}


val q3 = ctcfdb.projectS( "bed-count" -> count[Bed])


showSamples(q3)

for(s <- q3) println(s[Double]("bed-count"))


val q4 = {
   ctcfdb
   .projectS(
     "bed-count" -> count[Bed], 
     "sid" -> "sid")
}


for(s <- q4) println(s[String]("sid"), s[Double]("bed-count"))

showSamples(q4)



// Tests for more complicated queries.
//
// These queries use Synchrony iterators.


val mapres2 = showTiming {
  ctcfdb
  .mapS(ctcfdb)(onRegion =  mapR("avg_score" -> average(_.score),
                                 "stats" -> stats(_.score)))
}

val mapres3 = showTiming {
  ctcfdb
  .mapS(ctcfdb)(onRegion =  mapR("avg_score" -> average(_.score)))
}


val mapres = showTiming { 
  ctcfdb
   .mapS(ctcfdb)(
      onRegion = mapR("avg_score" -> average(_.score)),
      joinby = (u, v) => u("sid") == v("sid"))
}


showSamples(mapres)

showTrack(mapres(0))

showSize(mapres(0))



val grpbysid = {
  mapres2
  .groupbyS(
     grp = "sid",
     aggr = "count" -> count[Sample])
}


showSamples(grpbysid)

showTrack(grpbysid(1))




val grpbylocus = {
  mapres
  .onRegion(
     partitionbyR(
     aggr = "min-score" -> smallest(_.score), "reg-count" -> count))
}


showSamples(grpbylocus)

showSize(grpbylocus.samples(1))

grpbylocus(1).bedFile(5)  // Display region #5 on sample #1's track


{
  // test in grpbylocus whether sample #1's track is sorted.

  import synchrony.programming.Sri.withSlidingN

  val leq = Bed.ordering.lteq _

  grpbylocus(1).bedFile flatAggregateBy { withSlidingN(1) {
    OpG.forall { case (x, y) => leq(x(0), y) } } }
}
 



val refdb = SampleFile.inMemorySampleFile {
   ctcfdb.eiterator.take(1).toVector
}

val extdb = SampleFile.inMemorySampleFile {
   ctcfdb.eiterator.drop(1).toVector
}

val diffdb = showTiming {
  refdb.differenceS(extdb)(exact = false)
}


showSamples(diffdb)

showTrack(diffdb(0))

showSize(ctcfdb(0))

showSize(diffdb(0))




val joindb = showTiming {
  refdb
  .joinS(ctcfdb)(
     onRegion = joinR(geno = DGE(5000), DLE(100000))(limit = 100000))
}

joindb.eiterator.length

showSamples(joindb)

showSize(joindb(0))




val projres = showTiming {
  ctcfdb
  .projectS(onSample = "sid" -> metaS[String]("sid"),
                       "bed-count" -> aggrS(count))
}

val projres2 = showTiming {
  ctcfdb
  .projectS(onSample = "sid" -> "sid",
                       "bed-count" -> count[Bed])
}


showSamples(projres)


val selres = showTiming {
  ctcfdb
  .onRegion(_.selectR(_.chrom == "chr1"))
}


selres.slurped

selres(1).bedFile(10)




