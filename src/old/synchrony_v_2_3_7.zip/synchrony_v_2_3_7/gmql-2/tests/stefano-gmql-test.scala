
//
// Wong Limsoon
// 8/10/2010
//



import synchrony.gmql.EncodeNP._
import synchrony.gmql.SampleFileOps._
import synchrony.gmql.SampleFileOps.SFOps._
import synchrony.gmql.SampleFileOps.implicits._
import OpG.{ count, average, smallest, biggest }
import synchrony.genomeannot.BedFileOps._
import synchrony.genomeannot.BedFileOps.BFOps._
import synchrony.genomeannot.GenomeAnnot.GenomeLocus._



//
// Some functions for showing contents of samples.
//


def showSamples(samples: SampleFile) =
  for(s <- samples.eiterator) { 
    println(s); println("**")
  }


def showTotalSizeOnDisk(samples: SampleFile) = samples.totalsizeOnDisk


def showTrack(sample:Sample) = for(e <- sample.track) println(e) 


def showSize(sample:Sample) =
{
  val size = sample.bedFile.filesize
  val count = sample.track.length
  println(s"track size = ${size}, track count = ${count}")
}


def showTiming[A](codes: => A): A = {
  val t0 = System.nanoTime;
  val res = codes
  val dt = (System.nanoTime - t0) / 1e9d;
  println(s"Time take: ${dt}")
  res
}



//
// How GMQL's GDM is represented in Synchrony GMQL
//

/**
 *  Conceptually, GMQL's GDM can be thought of as a
 *  simple 1-level nested relation, 
 *
 *     EFile[Sample(l1, .., 
 *                  ln, 
 *                  track: EFile[Bed(chrom, 
 *                                   chromStart,
 *                                   chromEnd,
 *                                   strand,
 *                                   name
 *                                   score,
 *                                   r1, ..., rm))])]
 *
 *  where 
 *  l1, .., ln are metadata attributes of a sample;
 *  r1, .., rm are metadata attributes of a genomic region,
 *        which is just a row in a BED file;
 *  EFile can be thought of as a "file-based vector",
 *        which transparently materializes the parts of the
 *        vector of samples and BED rows into memory when
 *        they are needed in a computation.
 *
 *  Conceptually, a track/BED file is a relational table,
 *
 *    EFile[Bed(chrom,
 *              chromStart,
 *              chromEnd, 
 *              strand, 
 *              name, 
 *              score, 
 *              r1, .., rn)]
 *  where r1, .., rn are the metadata attributes on a region. 
 */


/** GMQL's MAP
 *
 *  MAP() rDB eDB
 */

def mapQ1a(rDB: SampleFile, eDB: SampleFile) = rDB.mapS(eDB)()

def mapQ1b(rDB: SampleFile, eDB: SampleFile) = mapS(rDB, eDB)()



/** GMQL's MAP
 *
 *  MAP(
 *    minScore  AS MIN(score);
 *    maxscore2 AS 2 * MAX(score)
 *    count_name: regNum;
 *    joinby: cellTissue
 *  ) rDB eDB
 */

def mapQ2a(rDB: SampleFile, eDB: SampleFile) =
  rDB.mapS(eDB)(
    onRegion = mapR("minScore"  -> smallest("score"),
                    "maxSCore2" -> (biggest[Bed]("score") |> (2 * _)))
                   ("regNum"),
    joinby   = "cellTissue"
  )


def mapQ2b(rDB: SampleFile, eDB: SampleFile) = 
  mapS(rDB, eDB)(
    onRegion = mapR("minScore" -> smallest("score"),
                    "maxSCore2" -> (biggest[Bed]("score") |> (2 * _)))
                   ("regNum"),
    joinby   = "cellTissue"
  )


/** GMQL' JOIN
 *
 *  JOIN(DL(0); output: INT) rDB eDB
 */

def join1a(rDB: SampleFile, eDB: SampleFile) =
  rDB.joinS(eDB)(onRegion = joinR(Overlap(1))(BFOut.intersect))


def join1b(rDB: SampleFile, eDB: SampleFile) =
  joinS(rDB, eDB)(onRegion = joinR(Overlap(1))(BFOut.intersect))



/** GMQL's SELECT
 *
 *  SELECT(region: (chr == chr1 OR chr == chr2)) eDB
 */


def select1a(eDB: SampleFile) =
  eDB.onRegion {  
    _.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
  }

 
def select1b(eDB: SampleFile) =
  onRegion(eDB) {  
    _.selectR( r => r.chrom == "chr1" || r.chrom == "chr2")
  }




/** GMQL, more complex query
 *
 * PLUS = SELECT(region: strand == +) genelists
 * PROM = PROJECT(region_update: 
 *                   start AS start - 2000,
 *                   stop AS stop + 1001) PLUS
 * MATCH = MAP (count_name: found) tfbslists PROM
 * RES = SELECT(region: found > 0) MATCH
 */


def complexQ1a(genelists: SampleFile, tfbslists: SampleFile) = {
  val plus = genelists.onRegion(_.selectR(_.strand == "+"))
  val prom = plus.onRegion(_.extendR(
                    "chromStart" -> (_[Int]("chromStart") - 2000),
                    "chromEnd"   -> (_[Int]("chromStart") + 1001)))
  val mapped = tfbslists.mapS(genelists)(onRegion =  mapR("found" -> count))
  mapped.onRegion(_.selectR(_[Int]("found") > 0))
}



/** GMQL's COVER
 *
 *  COVER(2, 3; groupby: cell; aggregate: minPVal AS MIN(pval)) db
 */


def coverQ(db: SampleFile) = {
  import BFCover.between
  db.coverS(
       onRegion = coverR(between(2, 3), "minPVal" -> smallest("pval")),
       onSample = "cell")
}








