package demo

import synchrony.gmql.GMQL
import GMQL._
import Predicates._
import GMQL.Projections._
import GMQL.GenomeLocus._
import GMQL.DB._
import GMQL.implicits._
import synchrony.gmql.EncodeNP._

import scala.language.postfixOps
import scala.io.Source._
import scala.collection.mutable.ListBuffer
import scala.math

import java.io.File
import java.io.PrintWriter

object Reporter {
	// Small object with auxiliary printing functions
	private def showSamples(db:DB) = db.samples.eiterator.foreach((s:Sample) => { println(s); println("**") } )

	private def showTrack(sample:Sample) = sample.track.foreach(println)

	private def showTrackHead(sample:Sample) = sample.track.slice(0,10).foreach(println)

	private def showSize(sample:Sample) = println(s"track size = ${sample.bedFile.filesize/1000.0} kb, track count = ${sample.track.length}")

	private def showTotalSize(db:DB) = println(s"total track size = ${db.samples.totalsizeOnDisk/(1000.0*1000.0)} mb")

	private def showTotalCount(db:DB) = println(s"total track count = ${countLines(db)} lines")

	private def mean(l:Seq[Double]): Double = l.reduceLeft(_ + _)/l.length
	
	private def std(l:Seq[Double]): Double = math.sqrt(mean(l.map((x:Double) => x * x)) - mean(l) * mean(l))
		

	def report(db:DB)
	{
		showSamples(db)
		showTotalSize(db)
		showTotalCount(db)
		db.samples.eiterator.zipWithIndex.foreach(
			{ case (s,count) => {println(s"Sample ${count}"); println(showSize(s)); showTrackHead(s)} }
		)
	}

	def sortTimes(ts:Seq[Double],name:String) {
		println(f"all ${name} times")
		println(ts)
		println("average")
		println(f"${mean(ts)}%10.6f")
		println("std")
		println(f"${std(ts)}%10.6f")
	}

	def countLines(db:DB) = db.samples.eiterator.foldLeft(0)((n,s) => n + s.track.length)
}

object SavUnwrapper {
	// reads and parses a sav file, then moves files from the temp variable folder


	def moveFiles(savpath:os.Path, tgtfldr:os.Path) {
		for (meta <- os.read.lines(savpath)
			if meta.split('\t')(0).startsWith("/var");
			p = os.Path(meta)) {
			os.move(p, tgtfldr / p.last)
		}
	}

}


object GMQLSynchro_Demo extends App {

	synchrony.iterators.Serializers.DEBUG = false // remove printouts
	synchrony.iterators.FileCollections.DEBUG = false // remove printouts
	GMQL.Projections.DEBUG = false // remove printouts
	GMQL.DEBUG = false // remove printouts

	// Set current working directory
	val wd = os.pwd
	val tmp_folder = os.root / "var" / "folders" / "k8" / "sf3vvc_921d8r9n7qgy_7kh00000gn" / "T"

	val NEXEC = 30
	val test_name = "001_1"

	// clean up output folders

	os.list(wd / "temp").foreach(f => os.remove(f))

	os.remove.all(wd / "tests" / "output" / s"${test_name}_output")

	val byte2mb = 1024*1024

	val usesH1DiffDatabasesAsInput1 = Set("007_3","007_4","007_5","007_6","007_10","007_11","007_12")
	val usesH1AsInput1 = Set("001_1","007_7")
	val usesHG19AsInput1 = Set("005_4","005_6","007_1","007_2","007_8","007_9","007_13","007_14","007_16")
	val usesSevenCellsAsInput1 = Set("005_5","007_15")
	val usesJoinRefAsInput1 = Set("join")
	val usesMBAsInput1 = Set("011_6")
	val usesBSAsInput1 = Set("011_7")
	val usesBMAsInput1 = Set("001_8")
	val usesBBAsInput1 = Set("010_9")
	val uses1SampleAsInput1 = Set("012_1","013_1")
	val uses5SampleAsInput1 = Set("012_2","013_2")
	val uses10SampleAsInput1 = Set("012_3","013_3")
	val uses20SampleAsInput1 = Set("012_4","013_4")
	val uses50SampleAsInput1 = Set("012_5","013_5")
	val uses75SampleAsInput1 = Set("012_6","013_6")
	val uses100SampleAsInput1 = Set("012_7","013_7")
	val uses1LineAsInput1 = Set("012_8","013_8")
	val uses10LineAsInput1 = Set("012_9","013_9")
	val uses100LineAsInput1 = Set("012_10","013_10")
	val uses1000LineAsInput1 = Set("012_11","013_11")
	val uses10000LineAsInput1 = Set("012_12","013_12")
	val uses100000LineAsInput1 = Set("012_13","013_13")
	val uses1000000LineAsInput1 = Set("012_14","013_14")


	val usesHeLaS3AsInput2 = Set("007_3","007_4","007_5","007_6","007_10","007_11","007_12")
	val usesH1AsInput2 = Set("001_1","001_8","007_1","005_5","007_2","007_8","007_9",
		"007_13","007_16","010_9","012_1","012_2","012_3","012_4","012_5",
		"012_6","012_7","012_8","012_9","012_10","012_11","012_12","012_13",
		"012_14")
	val usesHG19AsInput2 = Set("005_6","007_15")
	val usesH1DiffDatabasesAsInput2 = Set("007_7")
	val usesSevenCellsAsInput2 = Set("005_4","007_14")
	val usesJoinExpAsInput2 = Set("join")
	val usesMBAsInput2 = Set("011_6")
	val usesBSAsInput2 = Set("011_7")
	val uses1SampleAsInput2 = Set("013_1")
	val uses5SampleAsInput2 = Set("013_2")
	val uses10SampleAsInput2 = Set("013_3")
	val uses20SampleAsInput2 = Set("013_4")
	val uses50SampleAsInput2 = Set("013_5")
	val uses75SampleAsInput2 = Set("013_6")
	val uses100SampleAsInput2 = Set("013_7")
	val uses1LineAsInput2 = Set("013_8")
	val uses10LineAsInput2 = Set("013_9")
	val uses100LineAsInput2 = Set("013_10")
	val uses1000LineAsInput2 = Set("013_11")
	val uses10000LineAsInput2 = Set("013_12")
	val uses100000LineAsInput2 = Set("013_13")
	val uses1000000LineAsInput2 = Set("013_14")

	val gmqlResult = Map(
		"001_1" -> 12969)

	val dataset1_name = test_name match {
		case name if usesH1DiffDatabasesAsInput1 contains name => "H1_diff_databases"
		case name if usesSevenCellsAsInput1 contains name => "Seven_cells"
		case name if usesH1AsInput1 contains name => "H1"
		case name if usesHG19AsInput1 contains name => "HG19_BED_ANNOTATION"
		case name if usesJoinRefAsInput1 contains name => "join_test_ref"
		case name if usesMBAsInput1 contains name => "MB"
		case name if usesBSAsInput1 contains name => "BS"
		case name if usesBMAsInput1 contains name => "BM"
		case name if usesBBAsInput1 contains name => "BB"
		case name if uses1SampleAsInput1 contains name => "timings_1_sample"
		case name if uses5SampleAsInput1 contains name => "timings_5_samples"
		case name if uses10SampleAsInput1 contains name => "timings_10_samples"
		case name if uses20SampleAsInput1 contains name => "timings_20_samples"
		case name if uses50SampleAsInput1 contains name => "timings_50_samples"
		case name if uses75SampleAsInput1 contains name => "timings_75_samples"
		case name if uses100SampleAsInput1 contains name => "timings_100_samples"
		case name if uses1LineAsInput1 contains name => "timings_1_line"
		case name if uses10LineAsInput1 contains name => "timings_10_lines"
		case name if uses100LineAsInput1 contains name => "timings_100_lines"
		case name if uses1000LineAsInput1 contains name => "timings_1000_lines"
		case name if uses10000LineAsInput1 contains name => "timings_10000_lines"
		case name if uses100000LineAsInput1 contains name => "timings_100000_lines"
		case name if uses1000000LineAsInput1 contains name => "timings_1000000_lines"
		case "019_1" => "map_graph_1_ref"
		case "019_2" => "map_graph_2_ref"
		case "019_3" => "map_graph_3_ref"
		case "019_4" => "map_graph_4_ref"
		case "019_5" => "map_graph_5_ref"
		case "019_6" => "map_graph_6_ref"
		case "019_7" => "map_graph_7_ref"
		case "019_8" => "map_graph_8_ref"
		case "019_9" => "map_graph_9_ref"
		case "019_10" => "map_graph_10_ref"
		case "020_1" => "map_graph_1_on_ref_ref"
		case "020_2" => "map_graph_2_on_ref_ref"
		case "020_3" => "map_graph_3_on_ref_ref"
		case "020_4" => "map_graph_4_on_ref_ref"
		case "020_5" => "map_graph_5_on_ref_ref"
		case "020_6" => "map_graph_6_on_ref_ref"
		case "020_7" => "map_graph_7_on_ref_ref"
		case "020_8" => "map_graph_8_on_ref_ref"
		case "020_9" => "map_graph_9_on_ref_ref"
		case "020_10" => "map_graph_10_on_ref_ref"
		case _ => {println("Unknown test case"); sys.exit(1)}
	}

	val data_fldr = wd / "tests"

	val samplesdir = data_fldr / "input" / s"${dataset1_name}" / "files"
	val sampleslist = data_fldr / "input" / s"${dataset1_name}" / "list.txt"

	val processedAsBedPeaks = Set("HG19_BED_ANNOTATION","map_graph_1_ref",
		"map_graph_2_ref","map_graph_3_ref","map_graph_4_ref","map_graph_5_ref",
		"map_graph_6_ref","map_graph_7_ref","map_graph_8_ref","map_graph_9_ref",
		"map_graph_10_ref","map_graph_1_exp",
		"map_graph_2_exp","map_graph_3_exp","map_graph_4_exp","map_graph_5_exp",
		"map_graph_6_exp","map_graph_7_exp","map_graph_8_exp","map_graph_9_exp",
		"map_graph_10_exp",
		"map_graph_1_on_ref_ref",
		"map_graph_2_on_ref_ref","map_graph_3_on_ref_ref","map_graph_4_on_ref_ref","map_graph_5_on_ref_ref",
		"map_graph_6_on_ref_ref","map_graph_7_on_ref_ref","map_graph_8_on_ref_ref","map_graph_9_on_ref_ref",
		"map_graph_10_on_ref_ref","map_graph_1_on_ref_exp",
		"map_graph_2_on_ref_exp","map_graph_3_on_ref_exp","map_graph_4_on_ref_exp","map_graph_5_on_ref_exp",
		"map_graph_6_on_ref_exp","map_graph_7_on_ref_exp","map_graph_8_on_ref_exp","map_graph_9_on_ref_exp",
		"map_graph_10_on_ref_exp")


	var rdbFiles = dataset1_name match {
		case  name if processedAsBedPeaks contains name => altOnDiskDB(samplesdir.toString)(sampleslist.toString)
		case _ => altOnDiskEncodeNPDB(samplesdir.toString)(sampleslist.toString)
	}

	var usesTSS = Set("001_4","007_1","007_2","007_8","007_9","007_13","007_16")
	var usesGenes = Set("005_1","005_2","005_4","006_2","007_14")
	var usesOnlyPlusStrand = Set("005_6")

	val preloadRdb = test_name match {
		case name if usesTSS contains name => rdbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
		case name if usesGenes contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk;
		case name if usesOnlyPlusStrand contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq"),
																		 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk;
		case _ => rdbFiles.select().tracksSorted.materializedOnDisk

	}

	val rdbSorttimes = for (i <- 0 to (NEXEC-1)) yield {
		((t:Long) => {
			test_name match {
			case name if usesTSS contains name => rdbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
			case name if usesGenes contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk
			case name if usesOnlyPlusStrand contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq"),
																			 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk;		
			case _ => rdbFiles.select().tracksSorted.materializedOnDisk
			}; 
			(System.nanoTime()-t)/1e9
		}) (System.nanoTime())
	}

	val rdb = test_name match {
		case name if usesTSS contains name => rdbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
		case name if usesGenes contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk
		case name if usesOnlyPlusStrand contains name => rdbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq"),
																		 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk;		
		case _ => rdbFiles.select().tracksSorted.materializedOnDisk

	}

	os.list(wd / "temp").foreach(f => os.remove(f))

	Reporter.sortTimes(rdbSorttimes,"input1 sort")

	println()
	println("input1")

	Reporter.report(rdb)

	val dataset2_name = test_name match {
		case name if usesHeLaS3AsInput2 contains name => "HeLa-S3"
		case name if usesSevenCellsAsInput2 contains name => "Seven_cells"
		case name if usesH1AsInput2 contains name => "H1"
		case name if usesHG19AsInput2 contains name => "HG19_BED_ANNOTATION"
		case name if usesH1DiffDatabasesAsInput2 contains name => "H1_diff_databases"
		case name if usesJoinRefAsInput1 contains name => "join_test_exp"
		case name if usesMBAsInput2 contains name => "MB"
		case name if usesBSAsInput2 contains name => "BS"
		case name if usesBSAsInput2 contains name => "BS"
		case name if uses1SampleAsInput2 contains name => "timings_1_sample"
		case name if uses5SampleAsInput2 contains name => "timings_5_samples"
		case name if uses10SampleAsInput2 contains name => "timings_10_samples"
		case name if uses20SampleAsInput2 contains name => "timings_20_samples"
		case name if uses50SampleAsInput2 contains name => "timings_50_samples"
		case name if uses75SampleAsInput2 contains name => "timings_75_samples"
		case name if uses100SampleAsInput2 contains name => "timings_100_samples"
		case name if uses1LineAsInput2 contains name => "timings_1_line"
		case name if uses10LineAsInput2 contains name => "timings_10_lines"
		case name if uses100LineAsInput2 contains name => "timings_100_lines"
		case name if uses1000LineAsInput2 contains name => "timings_1000_lines"
		case name if uses10000LineAsInput2 contains name => "timings_10000_lines"
		case name if uses100000LineAsInput2 contains name => "timings_100000_lines"
		case name if uses1000000LineAsInput2 contains name => "timings_1000000_lines"
		case "019_1" => "map_graph_1_exp"
		case "019_2" => "map_graph_2_exp"
		case "019_3" => "map_graph_3_exp"
		case "019_4" => "map_graph_4_exp"
		case "019_5" => "map_graph_5_exp"
		case "019_6" => "map_graph_6_exp"
		case "019_7" => "map_graph_7_exp"
		case "019_8" => "map_graph_8_exp"
		case "019_9" => "map_graph_9_exp"
		case "019_10" => "map_graph_10_exp"
		case "020_1" => "map_graph_1_on_ref_exp"
		case "020_2" => "map_graph_2_on_ref_exp"
		case "020_3" => "map_graph_3_on_ref_exp"
		case "020_4" => "map_graph_4_on_ref_exp"
		case "020_5" => "map_graph_5_on_ref_exp"
		case "020_6" => "map_graph_6_on_ref_exp"
		case "020_7" => "map_graph_7_on_ref_exp"
		case "020_8" => "map_graph_8_on_ref_exp"
		case "020_9" => "map_graph_9_on_ref_exp"
		case "020_10" => "map_graph_10_on_ref_exp"
		case _ =>   {println("Unknown test case"); sys.exit(1)}
	}


	val samplesdir2 = data_fldr / "input" / s"${dataset2_name}" / "files"
	val sampleslist2 = data_fldr / "input" / s"${dataset2_name}" / "list.txt"

	var edbFiles = dataset2_name match {
		case name if processedAsBedPeaks contains name => altOnDiskDB(samplesdir2.toString)(sampleslist2.toString)
		case _ => altOnDiskEncodeNPDB(samplesdir2.toString)(sampleslist2.toString)
	}

	usesTSS = Set()
	usesGenes = Set("007_15")
	usesOnlyPlusStrand = Set("005_6")

	val preloadEdb = test_name match {
		case name if usesTSS contains name => edbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
		case name if usesGenes contains name => edbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk
		case name if usesOnlyPlusStrand contains name => edbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS"),
																		 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk
		case _ => edbFiles.select().tracksSorted.materializedOnDisk

	}

	val edbSorttimes = for (i <- 0 to (NEXEC-1)) yield {
		((t:Long) => {
			test_name match {
			case name if usesTSS contains name => edbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
			case name if usesGenes contains name => edbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk
			case name if usesOnlyPlusStrand contains name => edbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq"),
																			 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk;		
			case _ => edbFiles.select().tracksSorted.materializedOnDisk
			}; 
			(System.nanoTime()-t)/1e9
		}) (System.nanoTime())
	}

	val edb = test_name match {
		case name if usesTSS contains name => edbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS")).tracksSorted.materializedOnDisk;
		case name if usesGenes contains name => edbFiles.select(sample=OnSample(MetaS("provider") === "RefSeq")).tracksSorted.materializedOnDisk
		case name if usesOnlyPlusStrand contains name => edbFiles.select(sample=OnSample(MetaS("annotation_type") === "TSS"),
																		 region=OnRegion(Strand === "+")).tracksSorted.materializedOnDisk
		case _ => edbFiles.select().tracksSorted.materializedOnDisk
	}


	os.list(wd / "temp").foreach(f => os.remove(f))

	Reporter.sortTimes(edbSorttimes,"input2 sort")

	println()
	println("input2")

	Reporter.report(edb)

	println("Starting execution")

	val formatName = FunObj[String,String](s => s.replace("-human",""))
	val minusLog10 = FunObj[Double,Double](x => scala.math.log10 (1/x))
	val queries = Map(
		"001_1" -> DB.select()(rdb),
		"001_8" -> DB.select(region=OnRegion(Chr === "strange" or Chr === "funny"))(rdb),
		"005_4" -> DB.map(region=OnRegion("avgSig" as (Average of MetaR[Double]("signalval")),"reg_num" as Count))(rdb,edb),
		"005_5" -> DB.map(region=OnRegion("avgSig" as (Average of MetaR[Double]("signalval")),"reg_num" as Count))(rdb,edb),
		"005_6" -> DB.map(region=OnRegion())(rdb,edb),
		"007_1" -> DB.join(limit = 30000, pred = Genometric(DL(30000)), outputR = LeftR, orderR  = DistinctR) (rdb,edb),
		"007_2" -> DB.join(limit   = 100, pred    = Genometric(DL(100)), outputR = BothR()) (rdb,edb),
		"007_3" -> DB.join(limit = 20, pred = Genometric(DL(20)), outputR = IntR(),joinbyS = OnSample("database")) (rdb,edb),
		"007_4" -> DB.join(pred = Genometric(DLE(0)), outputR = IntR(), joinbyS = OnSample("database")) (rdb,edb),
		"007_5" -> DB.join(pred = Genometric(Overlap(20)), outputR = IntR(), joinbyS = OnSample("database")) (rdb,edb),
		"007_6" -> DB.join(pred = Genometric(Touch), outputR = LeftR, joinbyS = OnSample("database")) (rdb,edb),
		"007_7" -> DB.join(pred = Genometric(Overlap(1)), outputR = LeftR, joinbyR = OnRegion("score")) (rdb,edb),
		"007_8" -> DB.joinNearest(md = 1, predA = Genometric(StartBefore), outputR = RightR)(rdb,edb),
		"007_9" -> DB.joinNearest(md = 1, predB = Genometric(StartAfter), outputR = RightR)(rdb,edb),
		"007_10" -> DB.joinNearest(limit=500000,predB = Genometric(DGE(120000)), md=1,outputR = RightR,joinbyS=OnSample("database"))(rdb,edb),
		"007_11" -> DB.joinNearest(limit=500000,predB = Genometric(DGE(120000)), md=1,outputR = RightR,orderR=DistinctR,joinbyS=OnSample("database"))(rdb,edb),
		"007_12" -> DB.joinNearest(limit=500000,predB = Genometric(DGE(120000)), md=1,outputR = CatR(), joinbyS = OnSample("database"))(rdb,edb),
		"007_13" -> DB.join(limit=100000, pred = Genometric(DLE(10000),DGE(5000)), outputR = LeftR) (rdb,edb),
		"007_14" -> DB.join(limit=100000, pred = Genometric(DLE(10000),DGE(5000)), outputR = LeftR) (rdb,edb),
		"007_15" -> DB.join(limit=100000, pred = Genometric(DLE(10000),DGE(5000)), outputR = LeftR) (rdb,edb),
		"007_16" -> DB.joinNearest(md=1,outputR = RightR)(rdb,edb),
		"010_9" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"011_6" -> DB.map(region=OnRegion())(rdb,edb),
		"011_7" -> DB.map(region=OnRegion())(rdb,edb),
		"012_1" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_2" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_3" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_4" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_5" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_6" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_7" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_8" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_9" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_10" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_11" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_12" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_13" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"012_14" -> DB.select(region=OnRegion(Chr === "chr1" or Chr === "chr2"))(rdb),
		"013_1" -> DB.map(region=OnRegion())(rdb,edb),
		"013_2" -> DB.map(region=OnRegion())(rdb,edb),
		"013_3" -> DB.map(region=OnRegion())(rdb,edb),
		"013_4" -> DB.map(region=OnRegion())(rdb,edb),
		"013_5" -> DB.map(region=OnRegion())(rdb,edb),
		"013_6" -> DB.map(region=OnRegion())(rdb,edb),
		"013_7" -> DB.map(region=OnRegion())(rdb,edb),
		"013_8" -> DB.map(region=OnRegion())(rdb,edb),
		"013_9" -> DB.map(region=OnRegion())(rdb,edb),
		"013_10" -> DB.map(region=OnRegion())(rdb,edb),
		"013_11" -> DB.map(region=OnRegion())(rdb,edb),
		"013_12" -> DB.map(region=OnRegion())(rdb,edb),
		"013_13" -> DB.map(region=OnRegion())(rdb,edb),
		"013_14" -> DB.map(region=OnRegion())(rdb,edb),
		"019_1" -> DB.map(region=OnRegion())(rdb,edb),
		"019_2" -> DB.map(region=OnRegion())(rdb,edb),
		"019_3" -> DB.map(region=OnRegion())(rdb,edb),
		"019_4" -> DB.map(region=OnRegion())(rdb,edb),
		"019_5" -> DB.map(region=OnRegion())(rdb,edb),
		"019_6" -> DB.map(region=OnRegion())(rdb,edb),
		"019_7" -> DB.map(region=OnRegion())(rdb,edb),
		"019_8" -> DB.map(region=OnRegion())(rdb,edb),
		"019_9" -> DB.map(region=OnRegion())(rdb,edb),
		"019_10" -> DB.map(region=OnRegion())(rdb,edb),
		"020_1" -> DB.map(region=OnRegion())(rdb,edb),
		"020_2" -> DB.map(region=OnRegion())(rdb,edb),
		"020_3" -> DB.map(region=OnRegion())(rdb,edb),
		"020_4" -> DB.map(region=OnRegion())(rdb,edb),
		"020_5" -> DB.map(region=OnRegion())(rdb,edb),
		"020_6" -> DB.map(region=OnRegion())(rdb,edb),
		"020_7" -> DB.map(region=OnRegion())(rdb,edb),
		"020_8" -> DB.map(region=OnRegion())(rdb,edb),
		"020_9" -> DB.map(region=OnRegion())(rdb,edb),
		"020_10" -> DB.map(region=OnRegion())(rdb,edb),
		"join" -> DB.join(pred = Genometric(DL(20)), outputR = IntR(),joinbyS = OnSample("case")) (rdb,edb)
	)
	val preload = queries(test_name)
	Reporter.countLines(preload)

	def outdb = queries(test_name)
	val exectimes = for (i <- 0 to (NEXEC-1)) yield {
		((t:Long) => {Reporter.countLines(outdb); (System.nanoTime()-t)/1e9}) (System.nanoTime())
	}

	val writetimes = for (i <- 0 to (NEXEC-1)) yield {
		((t:Long) => {outdb.materializedOnDisk; (System.nanoTime()-t)/1e9}) (System.nanoTime())
	}

	println()

	Reporter.sortTimes(exectimes,"execution")
	Reporter.sortTimes(writetimes,"writing")

	println()
	println("output")
	Reporter.report(outdb)

	println("Matches GMQL?")
	println(Reporter.countLines(outdb) == gmqlResult(test_name))


	// Move output files to folder
	outdb.savedAs(s"${test_name}_output")
	os.move(wd / s"${test_name}_output.sfsav",
		wd / "tests" / "output" / s"${test_name}_output" / s"${test_name}_output.sfsav",
		createFolders=true)

	SavUnwrapper.moveFiles(wd / "tests" / "output" / s"${test_name}_output" / s"${test_name}_output.sfsav",
		wd / "tests" / "output" / s"${test_name}_output")

	val res = os.proc("zip", "-rj", 
		wd / s"${test_name}_output.zip", 
		wd / "tests" / "output" / s"${test_name}_output").call()


	// Move log and output to dropbox folder

	val dropbox_fldr = os.home / "Dropbox" / "nus" / "synchrony_iterators" / "tests"

	os.copy.over(wd / "log.txt",
		dropbox_fldr / s"${test_name}" / "log.txt",
		createFolders=false)

	os.move.over(wd / s"${test_name}_output.zip",
		dropbox_fldr / s"${test_name}" / "output"/ s"${test_name}_output.zip",
		createFolders=false)

	// Cleanup tmp files

	os.walk(tmp_folder,skip = (p: os.Path) => !(p.last.startsWith("synchrony-"))).foreach(os.remove(_))

	println(s"Test ${test_name} done.")

}